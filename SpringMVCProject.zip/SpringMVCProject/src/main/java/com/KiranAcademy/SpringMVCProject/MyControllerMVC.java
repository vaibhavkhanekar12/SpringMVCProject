package com.KiranAcademy.SpringMVCProject;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@Controller
public class MyControllerMVC {
	
	@RequestMapping("apicall")
	public String apicall() {
		
		return "apicall";
	}
	
	@RequestMapping("testapi")
	public ModelAndView test() {
		
		ArrayList<String> arraylist = new ArrayList<String>();
		arraylist.add("JBK");
		arraylist.add("JavaByKiran");
		arraylist.add("The Kiran Academy");
		
		//test is view name.
		//model means data which will be dispalyed on web page test.jsp
		//arraylist is model here
		//data is called modelAttribute and arrayList is it's value
		
		ModelAndView modelAndView = new ModelAndView("test","data",arraylist);
		
		return modelAndView;
	}
}

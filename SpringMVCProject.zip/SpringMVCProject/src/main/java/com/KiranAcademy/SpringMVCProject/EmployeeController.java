package com.KiranAcademy.SpringMVCProject;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@RestController

public class EmployeeController {
	
	@Autowired
	SessionFactory factory;
	
	@GetMapping("employee")
	List<Employee> allEmployee(){ 
	Session session =factory.openSession();
	List<Employee> arrayList=session.createCriteria(Employee.class).list();
	System.out.println(arrayList);
	return arrayList;
	}
	
	@GetMapping("employee/{rno}")
	public Employee getEmployee(@PathVariable int rno) {
		Session session=factory.openSession();
		Employee employee = session.load(Employee.class, rno);
		return employee;
	}
}

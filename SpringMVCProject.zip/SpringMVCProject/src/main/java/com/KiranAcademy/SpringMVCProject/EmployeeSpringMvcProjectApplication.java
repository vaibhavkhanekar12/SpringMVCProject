package com.KiranAcademy.SpringMVCProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")//When Package are different then use ComponentScan 
@EntityScan("com")//different entity 
public class EmployeeSpringMvcProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeSpringMvcProjectApplication.class, args);
	}

}

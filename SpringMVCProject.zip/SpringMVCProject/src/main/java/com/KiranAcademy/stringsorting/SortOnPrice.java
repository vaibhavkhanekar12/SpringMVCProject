package com.KiranAcademy.stringsorting;

import java.util.Comparator;

public class SortOnPrice implements Comparator<Mobiles> {

	public int compare(Mobiles mobile1, Mobiles mobile2) {
		Integer price1 = mobile1.getPrice();
		Integer price2 = mobile2.getPrice();

		if (price1.equals(price2))
			return - mobile1.getSpeed().compareTo(mobile2.getSpeed());

		return price1.compareTo(price2);

	}
}

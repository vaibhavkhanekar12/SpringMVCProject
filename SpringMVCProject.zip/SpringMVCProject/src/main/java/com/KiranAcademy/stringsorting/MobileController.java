package com.KiranAcademy.stringsorting;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MobileController {
	@Autowired
	SessionFactory factory;

	@RequestMapping("getData")
	public TreeSet<Mobiles> getData() {

		List<Mobiles> list = factory.openSession().createCriteria(Mobiles.class).list();

		TreeSet<Mobiles> treeset = new TreeSet<Mobiles>(new SortOnPrice());

		for (Mobiles mobile : list) {
			int price = mobile.getPrice();

			if (price >= 15 && price <= 30)
				treeset.add(mobile);

		}
		return treeset;
	}
}

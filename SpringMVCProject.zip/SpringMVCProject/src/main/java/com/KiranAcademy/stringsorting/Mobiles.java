package com.KiranAcademy.stringsorting;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mobiles {

	@Id
	@Column(name = "mobileid")
	private Integer mobileid;
	private Integer price;
	private Integer speed;

	public Mobiles() {
		super();
	}

	public Mobiles(Integer mobileid, Integer price, Integer speed) {
		super();
		this.mobileid = mobileid;
		this.price = price;
		this.speed = speed;
	}

	public Integer getMobileid() {
		return mobileid;
	}

	public void setMobileid(Integer mobileid) {
		this.mobileid = mobileid;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getSpeed() {
		return speed;
	}

	public void setSpeed(Integer speed) {
		this.speed = speed;
	}

	@Override
	public String toString() {
		return "Mobiles [mobileid=" + mobileid + ", price=" + price + ", speed=" + speed + "]";
	}

}
